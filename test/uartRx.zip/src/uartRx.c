#include "uartRx.h"
#include "ch32fun.h"
#include <stdbool.h>

#define USART1_RX_DMA_BUFF_SIZE (128) /* Must be a power of 2 to avoid using modulo division for rollbacks*/

static char usart_rx_buff[USART1_RX_DMA_BUFF_SIZE]; // Circular RX buffer
static volatile size_t uasrt_rx_counter; // Number of bytes stored in the buffer
static volatile size_t usart_rx_readindex; // Read index from the RX buffer.

// DMA transfer completion interrupt. It will fire when the DMA transfer is
// complete. We use it just to blink the LED
__attribute__((interrupt)) __attribute__((section(".srodata"))) void USART1_IRQHandler(void)
{
    // We only have configured the RXNE interrupt of USART1
    // However, it's supposedly cleared by DMA1_Channel5 since it reads USART1->DATAR to fill the circular buffer.
    uasrt_rx_counter++; // Increment the counter...
    uasrt_rx_counter &= (USART1_RX_DMA_BUFF_SIZE - 1); // ...and roll it over the max buffer size without using a costly modulo division.
    NVIC_ClearPendingIRQ(USART1_IRQn);
}

void UartRxInit(size_t baudRate)
{
    uasrt_rx_counter   = 0;
    usart_rx_readindex = 0;
    // Enable PORTD gpios and USART1
    RCC->APB2PCENR |= RCC_APB2Periph_GPIOD | RCC_APB2Periph_USART1;


    // GPIO D5 (TX) Push-Pull, 10MHz Output with AutoFunction
    GPIOD->CFGLR &= ~(0xf << (4 * 5)); // clear the old config for D5
    GPIOD->CFGLR |= (GPIO_Speed_10MHz | GPIO_CNF_OUT_PP_AF) << (4 * 5);

    // GPIO D6 (RX) as input
    GPIOD->CFGLR &= ~(0xf << (4 * 6)); // clear the old config for D6
    GPIOD->CFGLR |= (GPIO_CNF_IN_FLOATING) << (4 * 6);

    // Setup USART1 as 8N1 with "manual" Tx and DMA Rx,
    USART1->CTLR1 &= ~(CTLR1_UE_Set); // Disable USART1
    USART1->CTLR1 |= USART_WordLength_8b | USART_Parity_No | USART_Mode_Tx | USART_Mode_Rx | USART_CTLR1_RXNEIE;
    USART1->CTLR2 |= USART_StopBits_1;
    USART1->CTLR3 |= USART_HardwareFlowControl_None | USART_DMAReq_Rx;
    // And then our baud rate
    USART1->BRR = (((FUNCONF_SYSTEM_CORE_CLOCK) + (baudRate >> 1)) / (baudRate));

    // Enable DMA peripheral
    RCC->AHBPCENR = RCC_AHBPeriph_SRAM | RCC_AHBPeriph_DMA1;
    // Reset channel5 config
    DMA1_Channel5->CFGR = 0;
    // Clear all interrupt sources and flags for DMA1_Channel5
    DMA1->INTFR &= ~(DMA_GIF5 | DMA_TCIF5 | DMA_HTIF5 | DMA_TEIF5);
    DMA1->INTFCR = DMA_CGIF5 | DMA_CTCIF5 | DMA_CHTIF5 | DMA_CTEIF5;
    // Configure DMA1_Channel5

    DMA1_Channel5->MADDR = (uint32_t)(void*)usart_rx_buff;
    DMA1_Channel5->PADDR = (uint32_t)&(USART1->DATAR); // Point to the DATAR register as our peripheral
    DMA1_Channel5->CNTR  = sizeof(usart_rx_buff); // transfer size
    // Configure for UART1 RX
    DMA1_Channel5->CFGR = DMA_DIR_PeripheralSRC | DMA_MemoryInc_Enable | DMA_Mode_Circular | DMA_Priority_High;


    NVIC_EnableIRQ(USART1_IRQn); // Enable the USART1 interrupt.
    USART1->CTLR1 |= CTLR1_UE_Set; // enable USART1
    DMA1_Channel5->CFGR |= DMA_CFGR5_EN; // enable DMA1_Channel5
}


uint32_t uart_available()
{
    return uasrt_rx_counter;
}



int uart_read()
{
    static bool reentrant = false;
    if (reentrant)
        return -1;
    reentrant = true;
    if (uasrt_rx_counter) {
        char result = usart_rx_buff[usart_rx_readindex];
        usart_rx_readindex++; // move to the new read
        usart_rx_readindex &= (USART1_RX_DMA_BUFF_SIZE - 1); // roll over (no modulo on this RV32E core)
        uasrt_rx_counter--;
        reentrant = false;
        return result;
    }
    reentrant = false;
    return -1; // no character available
}

void uart_flush_RX()
{
    usart_rx_readindex += uasrt_rx_counter; // move to the new read
    usart_rx_readindex &= (USART1_RX_DMA_BUFF_SIZE - 1); // roll over (no modulo on this RV32E core)
    uasrt_rx_counter = 0;
}

/** @brief Get bytes from the circular RX buffer 
 * @param buffer Pointer to our destination buffer
 * @param count Number of bytes to retreive 
 * @returns The effective number of bytes copied into @p buffer.
*/
size_t uart_readBytes(char* dest, size_t count)
{
    static bool reentrant = false;
    size_t bytesRead      = 0;
    if (reentrant || dest == NULL || count == 0)
        return 0;

    reentrant = true;

    while (bytesRead < count && uasrt_rx_counter > 0) {
        dest[bytesRead] = usart_rx_buff[usart_rx_readindex];

        // Advance read index
        usart_rx_readindex++;
        usart_rx_readindex &= (USART1_RX_DMA_BUFF_SIZE - 1);

        // Decrement available counter
        uasrt_rx_counter--;

        bytesRead++;
    }
    reentrant = false;
    return bytesRead;
}
