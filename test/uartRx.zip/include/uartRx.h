#ifndef H_UART_RX_MODULE_H
#define H_UART_RX_MODULE_H

#include "ch32fun.h"

#ifdef __cplusplus
extern "C" {
#endif

void UartRxInit(size_t baudRate);


uint32_t uart_available();

int uart_read();

/** @brief Flushes the RX buffer */
void uart_flush_RX();


size_t uart_readBytes(char* buffer, size_t count);

#ifdef __cplusplus
}
#endif

#endif //!H_UART_RX_MODULE_H


